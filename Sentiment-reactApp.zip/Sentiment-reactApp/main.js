import React from 'react';
import ReactDOM from 'react-dom';
import FeedbackParent from './src/FeedbackParent.jsx';
import Score from './src/Score.jsx';
import Home from './src/Home.jsx';
import reducer from './src/reducers/index-reducer';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { Router, Route, browserHistory, IndexRoute} from 'react-router'

let store = createStore(reducer);

ReactDOM.render(
<Provider store={store}>
    <Router history = {browserHistory}>
      <Route path = "/" component = {Home}>
         <IndexRoute component = {FeedbackParent} />
         <Route path = "scores" component = {Score} />
      </Route>
   </Router>
</Provider>, 
document.getElementById('app'));

export default store;