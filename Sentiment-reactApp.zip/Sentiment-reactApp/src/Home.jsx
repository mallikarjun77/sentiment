import React from 'react';

class Home extends React.Component {

 constructor(props) {
      super(props);
		
      this.state = {
          TextStyle :{
        "fontSize":"250%",
        "fontFamily":"Verdana",
        "textAlign":"center"
        
    },
     PageStyle :{
         "background":'#75acf4',
         "PaddingTop":'10%',
         "paddingLeft":'20%',
         "paddingRight":'20%',
         "border":"1px solid black",
         
         "height":"100%",
         
        },
         AppBlockStyle :{
         "background":'white',
        "borderStyle":"groove",
        "borderRadius":"25px",
        "borderWidth":"2px",
         "marginBottom":"10%",
         "paddingLeft":'10%',
         "paddingRight":'10%',
         "paddingBottom":"3%", 
         "paddingTop":"3%",
        "height":"100%",
        },
       
      }
       
      
   };


   render() {
      return (
        <div style={this.state.PageStyle}>
             <p style={this.state.TextStyle}>
                     Sentiment Score App
                    </p>
              <div style={this.state.AppBlockStyle}>           
                    {this.props.children}
             </div>
         </div>
      );
   }
}



export default Home;