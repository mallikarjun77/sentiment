import React from 'react';

class Feedback extends React.Component {

 constructor(props) {
      super(props);
		
      this.state = {
          TextStyle :{
       "fontSize":"100%",
        "fontFamily":"Verdana",
        
    },
    TextAreaStyle :{
        "fontSize":"80%",
        "fontFamily":"Verdana",
        "height":"100px","width":"100%"
        },
      }
      
   };
 clear() {
    this.input.value = '';
  }

   render() {
      return (
        
              <div>
                    <p style={this.state.TextStyle}>
                    Feedback:
                    </p>
                    
                    <textarea  style={this.state.TextAreaStyle} ref={input => this.input = input} 
                   onChange={this.props.updateFeedbackTextProp} placeholder="enter your feedback here...."/>

         </div>
      );
   }
}



export default Feedback;