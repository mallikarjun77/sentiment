import React from 'react';
import Score from './Score.jsx';
import {connect} from 'react-redux';
import store from '../main.js';
import Feedback from './Feedback.jsx';
import { browserHistory } from 'react-router'



class FeedbackParent extends React.Component {
 constructor(props) {
      super(props);
		
      this.state ={
        feedback:this.props.feedback,
        feedbackText:'',
        noFeedbackInd:'false',

       
        
        TextStyle :{
        "fontSize":"100%",
        "fontFamily":"Verdana",
        
        },
        ErrorStyle :{
        "fontSize":"100%",
        "fontFamily":"Verdana",
        "color" : "red",
        
        },
         SubmitButtonStyle :{
            "backgroundColor":"#16ba07",
            "border":"none",
            "color":"white",
            "padding":"5px 12px","textAlign":"center",
            "textDecoration":"none",
            "display":"inline-block",
            "fontSize":"16px",
            "margin":"4px 2px",
            "cursor":"pointer",
            "borderRadius":"8px" 
        },
        ViewscoresButtonStyle :{
            "backgroundColor":"#FF4500",
            "border":"none",
            "color":"white",
            "padding":"5px 12px","textAlign":"center",
            "textDecoration":"none",
            "display":"inline-block",
            "fontSize":"16px",
            "margin":"4px 2px",
            "cursor":"pointer",
            "borderRadius":"8px" 
            },
      } 

      this.handleSubmit = this.handleSubmit.bind(this)
      this.updateFeedbackText = this.updateFeedbackText.bind(this)
      this.handleViewScores = this.handleViewScores.bind(this)
   };

   handleSubmit() {
       if(this.state.feedbackText.trim()!='')
       {
           console.log('inside if:'+this.state.feedbackText);
           this.state.noFeedbackInd='false';
           this.state.feedback.feedbackText=this.state.feedbackText.trim();
           this.state.feedback.feedbackSubmittedInd='true';
           this.state.feedbackText='';
           store.dispatch({type:'storefeedback', payload:this.state.feedback});
           // clear the input textarea after submitting
             this.input.clear();
           this.forceUpdate();
           return;
       }
       if(this.state.feedbackText.trim()=='')
       {
           this.state.noFeedbackInd='true';
           this.forceUpdate();
           return;
       }
   }
  
   
    updateFeedbackText(e) {
     this.state.feedbackText = e.target.value;
   }
   handleViewScores() {
        //Route to Sentiment Scores
     browserHistory.push('/scores')
   }
   render() {
      return (
         
              <div>
              
                <Feedback  ref={input => this.input = input} updateFeedbackTextProp={this.updateFeedbackText}/>
                <br/>
                <div>
                    <button style={this.state.SubmitButtonStyle} onClick={this.handleSubmit}>Submit</button>
                   
                   <button style={this.state.ViewscoresButtonStyle} onClick={this.handleViewScores}>View Scores</button>

                </div>
              
               
                 {(this.state.noFeedbackInd=='true')?
                <div>
                    <p style={this.state.ErrorStyle}>Please enter your feedback before submitting</p>
                </div>:''
                }

                
               
                </div>
        
      );
   }
}

function mapStateToProps(state){
    return {
        feedback : state.feedback
    };
}

export default connect(mapStateToProps) (FeedbackParent);