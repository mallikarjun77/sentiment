import React from 'react';
import { browserHistory } from 'react-router';
import Center from 'react-center';
import store from '../main.js';
import {$} from "jquery";

class Score extends React.Component {
    constructor(props) {
      super(props);
		
      this.state ={
        sentimentscores:[],
        loadingDataInd :'true',
         TextStyle :{
         "fontSize":"100%",
        "fontFamily":"Verdana",
        "textAlign":"center",
         },
          FeedbackButtonStyle :{
            "backgroundColor":"#FF4500",
            "border":"none",
            "color":"white",
            "padding":"5px 12px","textAlign":"center",
            "textDecoration":"none",
            "display":"inline-block",
            "fontSize":"16px",
            "margin":"4px 2px",
            "cursor":"pointer",
            "borderRadius":"8px" 
        },
      } 
      this.handleGiveFeedback = this.handleGiveFeedback.bind(this)

   };
   handleGiveFeedback() {
       //Route to Feedback
     browserHistory.push('/')
   }

componentWillMount() {
      //make Ajax call to get the data;
      var $ = require("jquery");     
           $.ajax({
          url: "http://localhost:8080/sentiment/webapi/posts",
          dataType: 'json',
          cache: false,
          success: function(data) {
            console.log(data);
              this.setState({sentimentscores: data});
              this.setState({loadingDataInd: 'false'});
          }.bind(this),
          error: function(xhr, status, err) {
            console.error(this.props.url, status, err.toString());
            this.setState({loadingDataInd: 'false'});
            alert("Web Service call failed. Please check the connection")
            
          }.bind(this)
            });
        
   }

    componentWillUnmount() {
      console.log('Component WILL UNMOUNT!');
       store.dispatch({type:'setSentimentScores', payload:this.state.sentimentscores});
   }
   render() {
      return (
          <div>
        <Center>
            {(this.state.sentimentscores.length!=0)?
            <div>
                <p style={this.state.TextStyle}>Sentiment Scores for the given feedbacks</p>
                {this.state.sentimentscores.map((sentimentscore, i) => <DisplayScore 
                    key = {i} sentimentscoreProp = {sentimentscore}/>)}
            <br/>
            </div>:
            <div>
                {(this.state.loadingDataInd=='true')?
                <p style={this.state.TextStyle}>Loading....</p>
                :<p style={this.state.TextStyle}>There are no records to show</p>}
            
            <br/>
            </div>}
           
         </Center>
          
         <Center>   
             <button style={this.state.FeedbackButtonStyle} onClick={this.handleGiveFeedback}>Give Feedback</button>
         </Center>
            </div>
         
      );
   }
}
class DisplayScore extends React.Component {
   render() {
      return (
          <div>
                <table style={this.props.tableStyle}>
                    <tbody>
                        <tr>
                            <td style={this.props.tdStyle}>
                                postId:
                            </td>
                            <td style={this.props.tdStyle}>
                                {this.props.sentimentscoreProp.postId}
                            </td>
                        </tr>
                        <tr>
                            <td style={this.props.tdStyle}>
                                associatedTone:
                            </td>
                            <td style={this.props.tdStyle}>
                                {this.props.sentimentscoreProp.associatedTone}
                            </td>
                        </tr>
                        <tr>
                            <td style={this.props.tdStyle}>
                                associatedToneScore:
                            </td>
                            <td style={this.props.tdStyle}>
                                {this.props.sentimentscoreProp.associatedToneScore}
                            </td>
                        </tr>
                         <tr>
                            <td style={this.props.tdStyle}>
                                postCreatedTime:
                            </td>
                            <td style={this.props.tdStyle}>
                                {this.props.sentimentscoreProp.postCreatedTime}
                            </td>
                        </tr>
                         <tr>
                            <td style={this.props.tdStyle}>
                                postCreatorType:
                            </td>
                            <td style={this.props.tdStyle}>
                                {this.props.sentimentscoreProp.postCreatorType}
                            </td>
                        </tr>
                         
                        <tr>
                            <td style={this.props.tdStyle}>
                                postText:
                            </td>
                            <td style={this.props.tdStyle}>
                                {this.props.sentimentscoreProp.postText}
                            </td>
                        </tr>
                    </tbody>
                </table>
         </div>
      );
   }
}

DisplayScore.defaultProps = {
    tdStyle :{
        "bgcolor":"#e4e8e1",
        "borderStyle":"groove",
        "borderWidth":"2px",
         "fontSize":"90%",
         "fontFamily":"Verdana"
    },
    tableStyle :{
        "borderStyle":"groove",
        "borderWidth":"2px",
    }
}


export default Score;